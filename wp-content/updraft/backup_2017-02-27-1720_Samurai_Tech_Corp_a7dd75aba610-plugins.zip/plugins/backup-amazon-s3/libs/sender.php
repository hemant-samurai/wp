<?php
if (!class_exists('sender')) {
    class sender {
        
    }
}