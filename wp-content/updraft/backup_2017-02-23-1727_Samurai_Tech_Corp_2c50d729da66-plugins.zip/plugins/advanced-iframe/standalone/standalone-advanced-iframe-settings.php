<?php

/** This are the options for the iframe. See all possible options in the documenation 
 *  or standalone-advanced-iframe.php 
 */
$iframeStandaloneOptions = array(
   'id' => 'example1',
   'name' => 'example1',
   'src' => 'http://www.tinywebgallery.com', 
   'width' => '600',
   'height' => '300',
   'enable_lazy_load' => 'true',
   'show_iframe_loader' => 'true' 
);    
?>