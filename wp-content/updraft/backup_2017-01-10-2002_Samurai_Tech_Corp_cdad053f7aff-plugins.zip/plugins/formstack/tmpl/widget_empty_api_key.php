<p>
    <label for="<?php print $keyFieldId; ?>">API Key:</label>
    <input id="<?php print $keyFieldId; ?>" name="<?php print $keyFieldName; ?>" />
</p>
