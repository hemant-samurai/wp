The browser detection uses a modified version of
http://wordpress.org/extend/plugins/php-browser-detection/

You can get an updated version of the browsercap.ini file here:
http://browscap.org/

Get the lite_php_browscap.ini from there and rename it to
php-browser-detection-browscap.ini

Or always get the latest version of the advanced iframe pro 
plugin. This file is also updated there!